import com.xl.window.DrawWindow;

public class DrawMain {
	
	public static void main(String[] args) {
		DrawWindow window= new DrawWindow();
		window.setVisible(true);
	}

}
